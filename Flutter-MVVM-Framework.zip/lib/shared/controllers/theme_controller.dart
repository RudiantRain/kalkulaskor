// lib/shared/controllers/theme_controller.dart
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../theme/app_theme.dart';

class ThemeController extends GetxController {
  final _box = GetStorage();
  final isDarkMode = false.obs;

  @override
  void onInit() {
    super.onInit();
    isDarkMode.value = _box.read<bool>('isDarkMode') ?? false; // ganti pola {'value': 'light'/'dark'} di referensi -> bool langsung
  }

  void toggleTheme() {
    isDarkMode.value = !isDarkMode.value;
    _box.write('isDarkMode', isDarkMode.value);
    Get.changeTheme(isDarkMode.value ? AppTheme.dark : AppTheme.light);
  }
}